<?php

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| Here you may define all of your model factories. Model factories give
| you a convenient way to create models for testing and seeding your
| database. Just tell the factory how a default model should look.
|
*/

use Illuminate\Database\Eloquent\Factory;

/** @var Factory $factory */
$factory->define(App\User::class, function (Faker\Generator $faker) {
    return [
        'name' => $faker->name,
        'email' => $faker->safeEmail,
        'password' => bcrypt(str_random(10)),
        'remember_token' => str_random(10),
    ];
});

$factory->define(App\Pelicula::class, function(Faker\Generator $faker){
    return [
        'titulo'           => $faker->words($faker->numberBetween(1, 5), true),
        'rating'           => $faker->numberBetween(0, 10),
        'fecha_de_estreno' => $faker->dateTimeBetween('-80 years', '+2 years'),
        'duracion'         => $faker->numberBetween(60, 60 * 4),
        'premios'          => $faker->numberBetween(0, 15),
    ];
});

$factory->define(App\Actor::class, function(Faker\Generator $faker){
    return [
        'nombre'   => $faker->firstName,
        'apellido' => $faker->lastName,
        'rating'   => $faker->numberBetween(1, 10),
        'id_pelicula_preferida' => function(){
            return factory(App\Pelicula::class)->create()->id;
        }
    ];
});
