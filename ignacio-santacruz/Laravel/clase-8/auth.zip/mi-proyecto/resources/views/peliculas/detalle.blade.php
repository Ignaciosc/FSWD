@extends('layout')

@section('contenido')
    <h1>{{ $pelicula->titulo }}</h1>
    <p>
        <!-- comentario html -->
        {{-- comentario blade '<script>alert("hola!")</script>' --}}
        Genero: {{ $pelicula->id_genero }}<br/>

        Año: {{ $pelicula->fecha_de_estreno->format('Y') }}<br/>
    </p>
@endsection