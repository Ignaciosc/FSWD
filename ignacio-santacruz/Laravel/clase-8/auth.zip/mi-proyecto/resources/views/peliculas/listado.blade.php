@extends('layouts.app')

@section('content')
    <h1>Listado de peliculas</h1>

    <ul class="list-group">
        @foreach ($peliculas as $pelicula)
        <li class="list-group-item">
            <div class="row">
                <div class="col-md-8">{{ $pelicula->titulo }} <span class="badge">{{ $pelicula->rating }}</span></div>
                <div class="col-md-4">
                    <form action="/peliculas/{{ $pelicula->id }}" method="post">
                        {{ csrf_field() }}
                        {{ method_field('delete') }}
                        <div class="btn-group">
                            <a class="btn btn-success" href="/peliculas/{{ $pelicula->id }}">Ver</a>
                            <a class="btn btn-primary" href="/peliculas/{{ $pelicula->id }}/editar">Editar</a>
                            <button type="submit" class="btn btn-danger">&times;</button>
                            </div>
                    </form>
                </div>
            </div>
        </li>
        @endforeach
    </ul>
@endsection