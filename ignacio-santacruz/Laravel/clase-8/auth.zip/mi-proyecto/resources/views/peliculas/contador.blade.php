<h2>Contador:</h2>

@for($i = 0; $i < 5; $i++)
    <div>{{ $i + $j }}</div>
@endfor

@while($i < 10)
    {{ $i / 2 }}
    @php($i++)
@endwhile
