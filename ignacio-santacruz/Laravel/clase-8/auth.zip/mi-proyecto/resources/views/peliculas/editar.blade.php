@extends('layout')

@section('contenido')
    <h1>Editar película: {{ $pelicula->titulo }}</h1>
    <form action="/peliculas" method="post">
        {{ csrf_field() }}
        <div class="form-group">
            <label for="titulo">Titulo</label>
            <input class="form-control" type="text" name="titulo" placeholder="Titulo de la pelicula" value="{{ $pelicula->titulo }}">
        </div>
        <div class="form-group">
            <label for="rating">Rating</label>
            <input class="form-control" type="number" name="rating" placeholder="Rating" value="{{ $pelicula->rating }}">
        </div>
        <div class="form-group">
            <label for="fecha_de_estreno">Fecha de estreno</label>
            <input class="form-control" type="date" name="fecha_de_estreno" placeholder="Estreno" value="{{ $pelicula->fecha_de_estreno->format('Y-m-d') }}">
        </div>
        <div class="form-group">
            <label for="duracion">Duración</label>
            <input class="form-control" type="number" name="duracion" placeholder="Duración (en minutos)" value="{{ $pelicula->duracion }}">
        </div>
        <div class="form-group">
            <label for="premios">Premios</label>
            <input class="form-control" type="number" name="premios" placeholder="Premios" value="{{ $pelicula->premios }}">
        </div>

        <button class="btn btn-primary" type="submit">Crear</button>
    </form>
@endsection