@extends('layout')

@section('contenido')
    <h1>Whoops! No encontre lo que me pediste.</h1>
@endsection