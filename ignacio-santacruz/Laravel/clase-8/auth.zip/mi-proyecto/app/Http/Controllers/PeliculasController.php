<?php

namespace App\Http\Controllers;

use App\Pelicula;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Requests\CrearPeliculaRequest;

class PeliculasController extends Controller
{
    public function listado()
    {
        $peliculas = Pelicula::all();

        return view('peliculas.listado', ['peliculas' => $peliculas]);
    }

    public function ver($id)
    {
        $laPelicula = Pelicula::findOrFail($id);

        /*
        if ($laPelicula == null) {
            abort(404);
        }
        */

        return view('peliculas.detalle', [
            'pelicula' => $laPelicula,
        ]);
    }

    public function agregar()
    {
        return view('peliculas.crear');
    }

    public function crear(CrearPeliculaRequest $request)
    {
        $pelicula = Pelicula::create(
            $request->only('titulo', 'rating', 'fecha_de_estreno', 'duracion', 'premios')
        );

        return redirect('/peliculas/' . $pelicula->id);
    }

    public function editar($id)
    {
        $pelicula = Pelicula::find($id);

        return view('peliculas.editar', [
            'pelicula' => $pelicula,
        ]);
    }

    public function actualizar($id, Request $request)
    {
        $pelicula = Pelicula::find($id);

//        $pelicula->titulo = $request->input('titulo'); // <form name="titulo"
//        $pelicula->rating = $request->input('rating');
        // ...

//        $pelicula->fill([
//            'titulo'            => $request->input('titulo'),
//            'rating'            => $request->input('rating'),
//            'fecha_de_estreno'  => $request->input('fecha_de_estreno'),
//            'duracion'          => $request->input('duracion'),
//            'premios'           => $request->input('premios'),
//        ]);

        $pelicula->fill($request->only('titulo', 'rating', 'fecha_de_estreno', 'duracion', 'premios'));

        $pelicula->save();

        return redirect('/peliculas/' . $pelicula->id);
    }

    public function eliminar($id)
    {
        // Alternativa: DELETE FROM directo.
//        $funciono = Pelicula::destroy($id);

//        if (! $funciono) {
//
//        }

        // Alternativa 2: SELECT + DELETE
        $pelicula = Pelicula::find($id);

        $pelicula->delete();

        return redirect('/');
    }
}
