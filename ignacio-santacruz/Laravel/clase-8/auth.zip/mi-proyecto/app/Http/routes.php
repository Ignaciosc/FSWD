<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

// La home - listado de peliculas
Route::get('/',               'PeliculasController@listado');

// Crear pelicula (formulario)
Route::get('/peliculas/agregar', 'PeliculasController@agregar');

// Detalle de pelicula
Route::get('/peliculas/{id}', 'PeliculasController@ver');

// Editar película (formulario)
Route::get('/peliculas/{id}/editar', [
    'middleware' => 'auth',
    'uses' => 'PeliculasController@editar'
]);

Route::group(['middleware' => 'auth', 'prefix' => '/peliculas'], function(){
    // Crear pelicula
    Route::post('/',     'PeliculasController@crear');

    Route::post('/{id}', 'PeliculasController@actualizar');

    Route::delete('/{id}', 'PeliculasController@eliminar');
});

Route::auth();

Route::get('/home', 'HomeController@index');

Route::resource('/generos', 'GeneroController');

Route::get('/facebook', function(){
    return Socialite::driver('facebook')->scopes(['user_friends'])->redirect();
});

Route::get('/facebook/callback', function(){
    dd(Socialite::driver('facebook')->fields(['friends'])->user());
});












