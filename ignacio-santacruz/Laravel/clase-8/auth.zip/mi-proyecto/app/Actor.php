<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Actor extends Model
{
    public $timestamps = false;

    protected $table = 'actor';

    protected $guarded = [];

    public function peliculas()
    {
        return $this->belongsToMany('App\Pelicula', 'actor_pelicula', 'id_actor', 'id_pelicula');
    }

    public function peliculaPreferida()
    {
        return $this->belongsTo('App\Pelicula', 'id_pelicula_preferida');
    }
}
