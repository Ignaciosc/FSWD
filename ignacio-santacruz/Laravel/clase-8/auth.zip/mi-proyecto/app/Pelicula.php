<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pelicula extends Model
{
    public $timestamps = false;

    protected $table = 'pelicula';

    protected $guarded = [];

    protected $dates = ['fecha_de_estreno'];

    public function genero()
    {
        return $this->belongsTo('App\Genero', 'id_genero');
    }
}
