<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Genero extends Model
{
    public $timestamps = false;

    protected $table = 'genero';

    protected $guarded = [];

    protected $dates = ['fecha_de_creacion'];

    public function peliculas()
    {
        return $this->hasMany('App\Pelicula', 'id_genero');
    }
}
