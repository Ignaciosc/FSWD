<?php

namespace App\Console\Commands;

use App\Actor;
use Illuminate\Console\Command;

class BuscarActorCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'actores:buscar {criterio : El criterio de busqueda} {--limite=5 : Cuantos devolver}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Buscar actores por nombre con un texto libre.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $criterio = $this->argument('criterio');
        $limite = $this->option('limite');

        $actores = Actor::where('nombre', 'LIKE', "%$criterio%")->take($limite)->get();

        if (count($actores) == 0) {
            $this->error('No encontré actores');

            return 7654;
        }

        $data = [];
        foreach ($actores as $actor) {
            $data[] = $actor->toArray();
        }

        $this->table(['id', 'nombre', 'apellido', 'rating', 'pelicula preferida'], $data);
    }
}
