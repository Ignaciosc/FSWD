<?php

namespace App\Console\Commands;

use App\Actor;
use Illuminate\Console\Command;

class CrearActorCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'actores:crear';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Crear actor de forma interactiva.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $datos = [
            'nombre' => $this->ask('Nombre del actor?'),
            'apellido' => $this->ask('Apellido del actor?'),
            'rating' => $this->ask('Rating del actor?', 5),
        ];

        $this->table(['nombre', 'apellido', 'rating'], [$datos]);
        if ($this->confirm('Esta seguro de que quiere crear el actor?')) {
            Actor::create($datos);

            $this->line('Cualquier mensaje');
            $this->warn("cuidado");
            $this->info('Datos utiles.');

            $this->error('Fallo algo!');
        } else {
            $this->error("Cancelado.");

            return 1;
        }
    }
}
