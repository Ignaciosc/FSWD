<?php $__env->startSection('content'); ?>
    <h1>Listado de peliculas</h1>

    <ul class="list-group">
        <?php foreach($peliculas as $pelicula): ?>
        <li class="list-group-item">
            <div class="row">
                <div class="col-md-8"><?php echo e($pelicula->titulo); ?> <span class="badge"><?php echo e($pelicula->rating); ?></span></div>
                <div class="col-md-4">
                    <form action="/peliculas/<?php echo e($pelicula->id); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('delete')); ?>

                        <div class="btn-group">
                            <a class="btn btn-success" href="/peliculas/<?php echo e($pelicula->id); ?>">Ver</a>
                            <a class="btn btn-primary" href="/peliculas/<?php echo e($pelicula->id); ?>/editar">Editar</a>
                            <button type="submit" class="btn btn-danger">&times;</button>
                            </div>
                    </form>
                </div>
            </div>
        </li>
        <?php endforeach; ?>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>