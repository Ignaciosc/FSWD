<?php $__env->startSection('contenido'); ?>
    <h1><?php echo e($pelicula->titulo); ?></h1>
    <p>
        <!-- comentario html -->
        <?php /* comentario blade '<script>alert("hola!")</script>' */ ?>
        Genero: <?php echo e($pelicula->id_genero); ?><br/>

        Año: <?php echo e($pelicula->fecha_de_estreno->format('Y')); ?><br/>
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>