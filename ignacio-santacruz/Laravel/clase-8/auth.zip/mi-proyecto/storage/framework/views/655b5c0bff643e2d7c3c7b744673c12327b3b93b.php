<h2>Contador:</h2>

<?php for($i = 0; $i < 5; $i++): ?>
    <div><?php echo e($i + $j); ?></div>
<?php endfor; ?>

<?php while($i < 10): ?>
    <?php echo e($i / 2); ?>

    <?php ($i++); ?>
<?php endwhile; ?>
