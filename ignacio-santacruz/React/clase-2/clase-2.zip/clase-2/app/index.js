import React from 'react';
import ReactDOM from 'react-dom';

const content = document.getElementById('content');

ReactDOM.render(<div>
        <span>Hola Mundo</span><br />
        <span>Soy Sergio</span>
      </div>
, content);
